# Image-process-2
Use convolution
